import sys
import json
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtCore, QtGui

import serial
import logging
import modbus_tk.modbus_tcp as mt
import modbus_tk.defines as md
import modbus_tk.modbus_rtu as mr


class Config(QMainWindow):
    def __init__(self, main_window=None) -> None:
        super().__init__()
        uic.loadUi('data/config.ui', self)
        self.setWindowTitle('Configurations')
        self.main_window = main_window
        self.setCentralWidget(self.cenwid)

        with open('data/config.json', 'r', encoding='utf-8') as file:
            self.file = json.loads(file.read())
            self.config = self.file['configurations'][0]

        # self.types = ["TCP", "RTU"]
        # self.stations = ["COM1", "LPT1"]
        # self.baudrates = [110, 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 38400, 56000, 57600, 115200, 128000]
        # self.stopbitss = [1, 2]
        # self.parities = [, , ]
        self.parities_for_modbus = {"нет контроля": 'N', "по нечетности": 'O', "по четности": 'E'}

        self.init_ui()

    def init_ui(self) -> None:
        # self.type.addItems(self.types)
        self.type.setCurrentText(self.config['type'])

        # self.station.addItems(self.stations)
        self.station.setCurrentText(self.config['station'])

        # self.baudrate.addItems(list(map(str, self.baudrates)))
        self.baudrate.setCurrentText(str(self.config['baudrate']))

        # self.stopbits.addItems(list(map(str, self.stopbitss)))
        self.stopbits.setCurrentText(str(self.config['stopbits']))

        # self.parity.addItems(self.parities)
        self.parity.setCurrentText(self.config['parity'])

        self.slave.setValue(self.config['slave'])
        self.timeout.setValue(self.config['timeout'])
        self.period.setValue(self.config['period'])
        self.server.setText(self.config['server'])
        self.port.setText(str(self.config['port']))

        self.btn.clicked.connect(self.click)

    def click(self) -> None:
        try:
            if self.check():
                # self.config['type'] = self.types[self.type.currentIndex()]
                # self.config['station'] = self.stations[self.station.currentIndex()]
                # self.config['baudrate'] = self.baudrates[self.baudrate.currentIndex()]
                # self.config['stopbits'] = self.stopbitss[self.stopbits.currentIndex()]
                # self.config['parity'] = self.parities_for_modbus[self.parity.currentIndex()]
                self.config['type'] = self.type.currentText()
                self.config['station'] = self.station.currentText()
                self.config['baudrate'] = int(self.baudrate.currentText())
                self.config['stopbits'] = int(self.stopbits.currentText())
                self.config['parity'] = self.parities_for_modbus[self.parity.currentText()]

                self.config['slave'] = self.slave.value()
                self.config['timeout'] = self.timeout.value()
                self.config['period'] = self.period.value()

                self.config['server'] = self.server.text()
                self.config['port'] = int(self.port.text())

                with open('data/config.json', 'w', encoding='utf-8') as file:
                    self.file['configurations'][0] = self.config
                    json.dump(self.file, file, ensure_ascii=False)
                self.statusbar.showMessage('Данные сохранены', 2000)
                # self.error.setText('<html><head/><body><p align="center"><span style=" font-size:10pt; '
                #                    'color:#028c19;">Готово!</span></p></body></html>')
            else:
                self.statusbar.showMessage('Ошибка!\nНеверно введен сервер или порт', 3000)
                # self.error.setText('<html><head/><body><p align="center"><span style=" font-size:10pt; '
                #                    'color:#c50003;">Неверно введен сервер или порт</span></p></body></html>')
        except Exception as s:
            print(s)

    def check(self) -> bool:
        server = self.server.text().split('.')
        if not all([i.isdigit() for i in server]):
            return False
        if not all([0 <= int(i) <= 255 for i in server]):
            return False
        return True

    def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
        if self.main_window:
            self.main_window.setEnabled(True)

    # def rrr(self):
    #     for i in range(1000000):
    #         QApplication.processEvents()
    #         print(i)

    # def configure(self):
    #     return self.config


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Config()
    ex.show()

    sys.exit(app.exec())


# {
#     "configurations": [
#         {
#             "type": ["TCP", "RTU"],
#             "station": ["COM1", "LPT1"],
#             "speed": [110, 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 38400, 56000, 57600, 115200, 128000],
#             "bit": [1, 2],
#             "control methods": ["нет контроля", "по нечетности", "по четности"],
#             "slave": 1,
#             "timeout": 1000,
#             "period": 10,
#             "server": "172.16.195.2",
#             "port": "502"
#         }
#     ]
# }

# {
#     "configurations": [
#         {
#             "type": "TCP",
#             "station": "COM1",
#             "baudrate": 110,
#             "stopbits": 1,
#             "parity": "N",
#             "slave": 1,
#             "timeout": 1000,
#             "period": 10,
#             "server": "172.16.195.2",
#             "port": "502"
#         }
#     ]
# }
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#
#     types_ = ["TCP", "RTU"]
#     stations_ = ["COM1", "LPT1"]
#     baudrates_ = [110, 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 38400, 56000, 57600, 115200, 128000]
#     stopbits_ = [1, 2]
#     parities_ = ["нет контроля", "по нечетности", "по четности"]
#     ex = Config(types_, stations_, baudrates_, stopbits_, parities_)
#     ex.show()
#
#     sys.exit(app.exec())

# class Config(QMainWindow):
#     def __init__(self, types, stations, baudrates, stopbitss, parities):
#         super().__init__()
#         uic.loadUi('data/config.ui', self)
#         self.setWindowTitle('Configurations')
#
#         with open('data/config.json', 'r', encoding='utf-8') as file:
#             self.file = json.loads(file.read())
#             self.config = self.file['configurations'][0]
#
#         self.types = types
#         self.stations = stations
#         self.baudrates = baudrates
#         self.stopbitss = stopbitss
#         self.parities = parities
#         self.parities_for_modbus = ['N', 'O', 'E']
#
#         self.init_ui()
