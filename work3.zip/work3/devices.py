import sys
import time
import json
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QDateTimeEdit
from PyQt5.QtCore import QTime, QDate
from config import Config
from modbus import ModbusInterface, Result
from PyQt5 import QtCore, QtGui
from PyQt5.QtCore import *


class Device:
    def __init__(self, name='', *args):
        self.name = name
        self.channels = {}
        for i in args:
            self.new_channel(*i)

    def new_channel(self, type_ch, channel, *inf):
        if type_ch in ['Di', 'Do']:
            bit = inf
            if type_ch in self.channels.keys():
                if channel in self.channels[type_ch].keys():
                    self.channels[type_ch][channel].append([bit, None,  None])
                else:
                    self.channels[type_ch][channel] = [bit, None,  None]
            else:
                self.channels[type_ch] = {channel: [bit, None,  None]}
        elif type_ch in ['Ci']:
            weight, units = inf
            if type_ch in self.channels.keys():
                if channel in self.channels[type_ch].keys():
                    self.channels[type_ch][channel].append([weight, None, units])
                else:
                    self.channels[type_ch][channel] = [weight, None, units]
            else:
                self.channels[type_ch] = {channel: [weight, None, units]}
        elif type_ch in ['Ai', 'Ao']:
            min_value, max_value, units = inf
            if type_ch in self.channels.keys():
                if channel in self.channels[type_ch].keys():
                    self.channels[type_ch][channel].append([min_value, max_value, units])
                else:
                    self.channels[type_ch][channel] = [min_value, max_value, units]
            else:
                self.channels[type_ch] = {channel: [min_value, max_value, units]}

    def __add__(self, other):
        other[self.name] = self.channels


# class GasAnalyzer(Device):
#     def __init__(self, name, *args):
#         channels =
#         super().__init__(name, *args)


class DevicesWindow(QMainWindow):
    def __init__(self, main_window) -> None:
        super().__init__()
        uic.loadUi('data/new_device.ui', self)
        self.setWindowTitle('New device')
        self.main_window = main_window
        self.tree = main_window.tree_value()
        self.setCentralWidget(self.cenwid)

        self.init_ui()

    def init_ui(self) -> None:
        self.add_btn.clicked.connect(self.add_device)

    def add_device(self) -> None:
        try:
            if self.device_name.text() == '':
                self.statusbar.showMessage('Не сохранено. Строка с названием пуста', 3000)
            elif self.device_name.text() in self.tree.keys():
                self.statusbar.showMessage('Устройство с таким именем уже существует', 3000)
            else:
                self.tree[self.device_name.text()] = {}
                self.main_window.load_tree(self.tree)
                self.statusbar.showMessage('Устройство добавлено', 3000)
        except Exception as s:
            print(s)

    def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
        self.main_window.setEnabled(True)


class DeviceChannelsWindow(QMainWindow):
    def __init__(self, main_window) -> None:
        super().__init__()
        uic.loadUi('data/new_channel.ui', self)
        self.setWindowTitle('New channel')
        self.main_window = main_window
        self.tree = main_window.tree_value()
        self.setCentralWidget(self.cenwid)

        self.init_ui()

    def init_ui(self) -> None:
        try:
            units = ['МПа', 'кПа', 'Па', 'бар', 'мм.рт.ст', '°C', '°F', 'K', 'т', 'ц', 'кг', 'гр', 'мг',
                     'л', 'м3', 'дм3', 'мл', 'см3', 'мм3']
            types = ['Ai', 'Ao', 'Di', 'Do', 'Ci']
            self.type.addItems(types)
            self.type.currentTextChanged.connect(self.change_type)
            self.device.currentTextChanged.connect(self.change_device)
            self.device.addItems(self.tree.keys())

            self.units.addItems(units)
            self.add_btn.clicked.connect(self.add_channel)
        except Exception as s:
            print(s)

    def change_device(self):
        self.type.clear()
        self.type.addItems(self.tree[self.device.currentText()].keys())

    def change_type(self):
        self.name.clear()
        types = self.tree[self.device.currentText()]
        if self.type.currentText() in types.keys():
            self.name.addItems(types[self.type.currentText()])

    def add_channel(self) -> None:
        try:
            device = self.device.currentText()
            typed = self.type.currentText()
            name = self.name.currentText()
            minv = self.min_value.value()
            maxv = self.max_value.value()
            units = self.units.currentText()

            if not all([name, units]):
                self.statusbar.showMessage('Не сохранено, так как есть пустые поля', 3000)
                return
            if minv > maxv:
                self.statusbar.showMessage('Минимальное значение должно быть меньше максимального', 3000)
                return

            if typed in self.tree[device]:
                if name in self.tree[device][typed].keys():
                    self.statusbar.showMessage('Такой канал уже есть', 3000)
                    return
                else:
                    self.tree[device][typed][name] = [minv, maxv, units]
            else:
                self.tree[device][typed] = {name: [minv, maxv, units]}
            self.main_window.load_tree(self.tree)
            self.statusbar.showMessage('Готово!', 3000)
        except Exception as s:
            print(s)

    def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
        self.main_window.setEnabled(True)


if __name__ == '__main__':
    device = Device('mass', ('Ai', 'kk1', -50.0, 100.0, "K"))
    device.new_channel('Ai', "n02", -20.0, 120.0, "гр")
    device.new_channel('Di', "n03", -70.0, 120.0, "C")

    print(device.channels)

    f = {'ll': [1], device.name: device.channels}

    print(f)
