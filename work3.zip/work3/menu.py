import sys
import json
import time
from time_for_modbus import TimeModbus
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidget, QTreeWidget, QTableWidgetItem, QDoubleSpinBox, QComboBox
from PyQt5.QtWidgets import *
from config import Config
from modbus import ModbusInterface, Result
from devices import DevicesWindow, DeviceChannelsWindow
from PyQt5 import QtCore, QtGui
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *


# def print_values(values, address, length):
#     return '\n'.join([f'{str(address + i)}:\t{str(values[i])}' for i in range(length)])


class Menu(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        uic.loadUi('data/menu.ui', self)
        self.setWindowTitle('Modbus')

        with open('data/config.json', 'r', encoding='utf-8') as file:
            self.file = json.loads(file.read())

        self.thread_manager = QThreadPool()
        self.init_ui()

    def init_ui(self) -> None:
        self.setCentralWidget(self.cenwidget)

        self.address.setValue(self.file['menu']['address'])
        self.length.setValue(self.file['menu']['length'])
        self.save_btn.clicked.connect(self.save)

        self.act_connect.setStatusTip('Подключение')
        self.act_connect.triggered.connect(self.run_thread)
        self.act_disconnect.setStatusTip('Отключение')
        self.act_disconnect.triggered.connect(self.discon)

        self.act_settings.setStatusTip('Настройки параметров соединения')
        self.act_settings.triggered.connect(self.settings)

        self.act_time.setStatusTip('Просмотр времени')
        self.act_time.triggered.connect(self.time_date)

        self.act_device.setStatusTip('Добавить устройство')
        self.act_device.triggered.connect(self.new_device)

        self.act_channel.setStatusTip('Добавить канал')
        self.act_channel.triggered.connect(self.new_channel)

        self.con = Config(self)
        self.load_tree()
        # self.tree.itemChanged.connect(self.handle)

    @pyqtSlot()
    def run_thread(self) -> None:
        self.thread_manager.start(self.run)

    @pyqtSlot()
    def run(self) -> None:
        self.flag_run = True

        while self.flag_run:
            try:
                address = self.address.value()
                length = self.length.value()
                # config = self.con.config
                master = ModbusInterface()
                result = master.read_from_holding_registers(address, length)

                assert result.status == 'ok'
                title_column = ['Decimal']
                title_row = [str(i) + ': ' for i in range(address, address + length + 1)]
                self.table.setColumnCount(len(title_column))
                self.table.setRowCount(length)
                self.table.setVerticalHeaderLabels(title_row)
                self.table.setHorizontalHeaderLabels(title_column)
                for type_nums in range(1):
                    for i, num in enumerate(result.data):
                        self.table.setItem(type_nums, i, QTableWidgetItem(str(num)))

                self.table.resizeColumnsToContents()
                self.table.resizeRowsToContents()

                self.statusbar.showMessage('run', 2000)
            except Exception as s:
                print(s)
                self.statusbar.showMessage('ERROR:  ' + s.__class__.__name__, 5000)
                self.flag_run = False
            time.sleep(5)

    def discon(self) -> None:
        self.flag_run = False

    def load_tree(self, data=None) -> None:
        self.tree.clear()
        if data is None:
            data = self.file['devices']
        units = {'давление': ['МПа', 'кПа', 'Па', 'бар', 'мм.рт.ст'],
                 'температура': ['°C', '°F', 'K'],
                 'масса': ['т', 'ц', 'кг', 'гр', 'мг'],
                 'объём': ['л', 'м3', 'дм3', 'мл', 'см3', 'мм3'],
                 # 'перепад ': ['', '', '', '', '']
                 }
        # , "units": ["Па", "кПа", "C", "K"]
        # self.tree = QTreeWidget(self)

        items = []
        self.devices_widgets = {}

        for key, values in data.items():
            item = QTreeWidgetItem([key])
            self.devices_widgets[key] = {}

            for j in values.keys():
                valu = values[j]
                child1 = QTreeWidgetItem([j])
                child1.setFlags(child1.flags() | Qt.ItemIsEditable)
                self.devices_widgets[key][j] = {}

                for k in valu.keys():
                    val = valu[k]
                    # child = QTreeWidgetItem([k, *[str(i) for i in val]])
                    child = QTreeWidgetItem([k])
                    # child.setFlags(child.flags() | Qt.ItemIsEditable)
                    child1.addChild(child)
                    if j in ["Ai", "Ao"]:
                        self.devices_widgets[key][j][k] = [QDoubleSpinBox(self), QDoubleSpinBox(self), QComboBox(self)]
                        self.devices_widgets[key][j][k][0].setMinimum(-99999)
                        self.devices_widgets[key][j][k][0].setMaximum(99999)
                        self.devices_widgets[key][j][k][0].setValue(val[0])
                        self.devices_widgets[key][j][k][1].setMinimum(-99999)
                        self.devices_widgets[key][j][k][1].setMaximum(99999)
                        self.devices_widgets[key][j][k][1].setValue(val[1])

                        combobox_empty = True
                        for i in units.keys():
                            if val[2] in units[i]:
                                self.devices_widgets[key][j][k][2].addItems(units[i])
                                combobox_empty = False
                                break
                        if combobox_empty:
                            self.devices_widgets[key][j][k][2].addItem(val[2])
                        self.devices_widgets[key][j][k][2].setCurrentText(val[2])
                        # self.devices_widgets[key][j][k][2].setMaximumWidth(70)
                        # self.channels_widgets[-1][2].setEditable(True)

                        self.tree.setItemWidget(child, 1, self.devices_widgets[key][j][k][0])
                        self.tree.setItemWidget(child, 2, self.devices_widgets[key][j][k][1])
                        self.tree.setItemWidget(child, 3, self.devices_widgets[key][j][k][2])
                    elif j in ['Di', 'Do']:
                        self.devices_widgets[key][j][k] = [QCheckBox(self)]
                        if val[0] == 1:
                            self.devices_widgets[key][j][k][0].setChecked(True)
                        self.tree.setItemWidget(child, 1, self.devices_widgets[key][j][k][0])

                    elif j in ['Ci']:
                        self.devices_widgets[key][j][k] = [QDoubleSpinBox(self), QComboBox(self)]
                        self.devices_widgets[key][j][k][0].setMinimum(-99999)
                        self.devices_widgets[key][j][k][0].setMaximum(99999)
                        self.devices_widgets[key][j][k][0].setValue(val[0])

                        combobox_empty = True
                        for i in units.keys():
                            if val[1] in units[i]:
                                self.devices_widgets[key][j][k][1].addItems(units[i])
                                combobox_empty = False
                                break
                        if combobox_empty:
                            self.devices_widgets[key][j][k][1].addItem(val[1])
                        self.devices_widgets[key][j][k][1].setCurrentText(val[1])
                        # self.devices_widgets[key][j][k][1].setMaximumWidth(70)

                        self.tree.setItemWidget(child, 2, self.devices_widgets[key][j][k][0])
                        self.tree.setItemWidget(child, 3, self.devices_widgets[key][j][k][1])

                item.addChild(child1)
            items.append(item)
        self.tree.insertTopLevelItems(0, items)

        self.tree_value()

    def tree_value(self) -> dict:
        it = QTreeWidgetItemIterator(self.tree)
        data = {}

        for device in self.devices_widgets.keys():
            data[device] = {}
            for channel in self.devices_widgets[device].keys():
                data[device][channel] = {}
                for i in self.devices_widgets[device][channel].keys():
                    items = self.devices_widgets[device][channel][i]
                    if channel in ['Ai', 'Ao']:
                        data[device][channel][i] = [items[0].value(), items[1].value(), items[2].currentText()]
                    elif channel in ['Di', 'Do']:
                        data[device][channel][i] = [1] if items[0].isChecked() else [0]
                    elif channel in ['Ci']:
                        data[device][channel][i] = [items[0].value(), items[1].currentText()]
        print(data)
        # title = []
        # f = True
        # n = 0

        # while it.value():
        #     item = it.value()
        #     items = item.text(0), item.text(1), item.text(2), item.text(3)
        #     print(items)
        #     if all(items):
        #         data[title][items[0]] = [self.channels_widgets[n][0].value(),
        #                                  self.channels_widgets[n][1].value(),
        #                                  self.channels_widgets[n][2].currentText()]
        #         n += 1
        #     else:
        #         title.append(items[0])
        #         data[title] = {}
        #     it += 1
        return data

    def save(self) -> None:
        try:
            new_data = []
            for i in range(self.table.rowCount()):
                for j in range(self.table.columnCount()):  # только для decimal
                    new_data.append(int(self.table.item(i, j).text()))
            master = ModbusInterface()
            result = master.write_to_holding_registers(int(self.table.verticalHeaderItem(0).text()[:-2]),
                                                       self.table.rowCount(), new_data)
            assert result.status == 'ok'
            self.statusbar.showMessage('Сохранено', 3000)
        except AttributeError:
            self.statusbar.showMessage('Данные для сохранения отсутствуют', 2000)
        except Exception as s:
            print(s)
            self.statusbar.showMessage('Возникла ошибка:  ' + s.__class__.__name__, 2000)

    def settings(self) -> None:
        self.con.show()
        self.setEnabled(False)
        self.flag_run = False

    def time_date(self) -> None:
        master = ModbusInterface()
        self.tm = TimeModbus(master, self)
        self.setEnabled(False)
        self.tm.show()
        self.flag_run = False

    def new_device(self) -> None:
        self.dw = DevicesWindow(self)
        self.dw.show()
        self.setEnabled(False)
        self.flag_run = False

    def new_channel(self) -> None:
        self.dc = DeviceChannelsWindow(self)
        self.dc.show()
        self.setEnabled(False)
        self.flag_run = False

    def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
        try:
            with open('data/config.json', 'w', encoding='utf-8') as newfile:
                self.file['menu']['address'] = self.address.value()
                self.file['menu']['length'] = self.length.value()
                self.file['devices'] = self.tree_value()
                json.dump(self.file, newfile, ensure_ascii=False)
        except Exception as s:
            print(s)
        print('close')
        self.flag_run = False


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Menu()
    ex.show()
    sys.exit(app.exec())


# import sys
# import json
# import time
# from time_for_modbus import TimeModbus
# from PyQt5 import uic
# from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidget, QTreeWidget, QTableWidgetItem, QDoubleSpinBox, QComboBox
# from config import Config
# from modbus import ModbusInterface, Result
# from PyQt5 import QtCore, QtGui
# from PyQt5.QtGui import *
# from PyQt5.QtWidgets import *
# from PyQt5.QtCore import *
#
#
# # def print_values(values, address, length):
# #     return '\n'.join([f'{str(address + i)}:\t{str(values[i])}' for i in range(length)])
#
#
# class Menu(QMainWindow):
#     def __init__(self) -> None:
#         super().__init__()
#         uic.loadUi('data/menu.ui', self)
#         self.setWindowTitle('Modbus')
#
#         with open('data/config.json', 'r', encoding='utf-8') as file:
#             self.file = json.loads(file.read())
#
#         self.thread_manager = QThreadPool()
#         self.init_ui()
#
#     def init_ui(self) -> None:
#         self.setCentralWidget(self.cenwidget)
#
#         self.address.setValue(self.file['menu']['address'])
#         self.length.setValue(self.file['menu']['length'])
#         self.save_btn.clicked.connect(self.save)
#
#         self.act_connect.setStatusTip('Подключение')
#         self.act_connect.triggered.connect(self.run_thread)
#         self.act_disconnect.setStatusTip('Отключение')
#         self.act_disconnect.triggered.connect(self.discon)
#
#         self.act_settings.setStatusTip('Настройки параметров соединения')
#         self.act_settings.triggered.connect(self.settings)
#
#         self.act_time.setStatusTip('Просмотр времени')
#         self.act_time.triggered.connect(self.time_date)
#
#         self.con = Config(self)
#         self.load_tree()
#         # self.tree.itemChanged.connect(self.handle)
#
#     @pyqtSlot()
#     def run_thread(self) -> None:
#         self.thread_manager.start(self.run)
#
#     @pyqtSlot()
#     def run(self) -> None:
#         self.flag_run = True
#
#         while self.flag_run:
#             try:
#                 address = self.address.value()
#                 length = self.length.value()
#                 # config = self.con.config
#                 master = ModbusInterface()
#                 result = master.read_from_holding_registers(address, length)
#
#                 assert result.status == 'ok'
#                 title_column = ['Decimal']
#                 title_row = [str(i) + ': ' for i in range(address, address + length + 1)]
#                 self.table.setColumnCount(len(title_column))
#                 self.table.setRowCount(length)
#                 self.table.setVerticalHeaderLabels(title_row)
#                 self.table.setHorizontalHeaderLabels(title_column)
#                 for type_nums in range(1):
#                     for i, num in enumerate(result.data):
#                         self.table.setItem(type_nums, i, QTableWidgetItem(str(num)))
#
#                 self.table.resizeColumnsToContents()
#                 self.table.resizeRowsToContents()
#
#                 self.statusbar.showMessage('run', 2000)
#             except Exception as s:
#                 print(s)
#                 self.statusbar.showMessage('ERROR:  ' + s.__class__.__name__, 5000)
#                 self.flag_run = False
#             time.sleep(5)
#
#     def discon(self) -> None:
#         self.flag_run = False
#
#     def load_tree(self) -> None:
#         units = {'давление': ['МПа', 'кПа', 'Па', 'бар', 'мм.рт.ст'],
#                  'температура': ['°C', '°F', 'K'],
#                  'масса': ['т', 'ц', 'кг', 'гр', 'мг'],
#                  'объём': ['л', 'м3', 'дм3', 'мл', 'см3', 'мм3'],
#                  # 'перепад ': ['', '', '', '', '']
#                  }
#         # , "units": ["Па", "кПа", "C", "K"]
#         # self.tree = QTreeWidget(self)
#
#         items = []
#         self.channels_widgets = []
#
#         for key, values in self.file['channels'].items():
#             item = QTreeWidgetItem([key])
#
#             for k in values.keys():
#                 val = values[k]
#                 child = QTreeWidgetItem([k, *[str(i) for i in val]])
#                 child.setFlags(child.flags() | Qt.ItemIsEditable)
#                 item.addChild(child)
#
#                 self.channels_widgets.append([QDoubleSpinBox(self), QDoubleSpinBox(self), QComboBox(self)])
#                 self.channels_widgets[-1][0].setMinimum(-99999)
#                 self.channels_widgets[-1][0].setMaximum(99999)
#                 self.channels_widgets[-1][0].setValue(val[0])
#                 self.channels_widgets[-1][1].setMinimum(-99999)
#                 self.channels_widgets[-1][1].setMaximum(99999)
#                 self.channels_widgets[-1][1].setValue(val[1])
#
#                 for i in units.keys():
#                     if val[2] in units[i]:
#                         self.channels_widgets[-1][2].addItems(units[i])
#                         break
#                 self.channels_widgets[-1][2].setCurrentText(val[2])
#                 # self.channels_widgets[-1][2].setEditable(True)
#
#                 self.tree.setItemWidget(child, 1, self.channels_widgets[-1][0])
#                 self.tree.setItemWidget(child, 2, self.channels_widgets[-1][1])
#                 self.tree.setItemWidget(child, 3, self.channels_widgets[-1][2])
#             items.append(item)
#         self.tree.insertTopLevelItems(0, items)
#         self.tree_value()
#
#     def tree_value(self) -> dict:
#         it = QTreeWidgetItemIterator(self.tree)
#         data = {}
#         title = ''
#         n = 0
#
#         while it.value():
#             item = it.value()
#             items = item.text(0), item.text(1), item.text(2), item.text(3)
#             if all(items):
#                 data[title][items[0]] = [self.channels_widgets[n][0].value(),
#                                          self.channels_widgets[n][1].value(),
#                                          self.channels_widgets[n][2].currentText()]
#                 n += 1
#             else:
#                 title = items[0]
#                 data[title] = {}
#             it += 1
#         return data
#
#     # def handle(self):
#     #     print(4)
#
#     def save(self) -> None:
#         try:
#             new_data = []
#             for i in range(self.table.rowCount()):
#                 for j in range(self.table.columnCount()):  # только для decimal
#                     new_data.append(int(self.table.item(i, j).text()))
#             master = ModbusInterface()
#             result = master.write_to_holding_registers(int(self.table.verticalHeaderItem(0).text()[:-2]),
#                                                        self.table.rowCount(), new_data)
#             assert result.status == 'ok'
#             self.statusbar.showMessage('Сохранено', 3000)
#         except AttributeError:
#             self.statusbar.showMessage('Данные для сохранения отсутствуют', 2000)
#         except Exception as s:
#             print(s)
#             self.statusbar.showMessage('Возникла ошибка:  ' + s.__class__.__name__, 2000)
#
#     def settings(self) -> None:
#         self.con.show()
#         self.setEnabled(False)
#         self.flag_run = False
#
#     def time_date(self) -> None:
#         master = ModbusInterface()
#         self.tm = TimeModbus(master, self)
#         self.setEnabled(False)
#         self.tm.show()
#         self.flag_run = False
#
#     def closeEvent(self, a0: QtGui.QCloseEvent) -> None:
#         try:
#             with open('data/config.json', 'w', encoding='utf-8') as newfile:
#                 self.file['menu']['address'] = self.address.value()
#                 self.file['menu']['length'] = self.length.value()
#                 self.file['channels'] = self.tree_value()
#                 json.dump(self.file, newfile, ensure_ascii=False)
#         except Exception as s:
#             print(s)
#         print('close')
#         self.flag_run = False
#
#
# if __name__ == '__main__':
#     app = QApplication(sys.argv)
#     ex = Menu()
#     ex.show()
#     sys.exit(app.exec())